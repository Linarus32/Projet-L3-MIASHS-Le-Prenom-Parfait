<!DOCTYPE html>
<html>

<head>

<title>Ajout a vos favoris</title>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
<link rel="stylesheet" href="css/v1-sarah.css" type="text/css" media="screen" />


<?php

session_start();

if(isset($_SESSION['Client']) && $_GET['idprenom']){ //la variable existe: le client est connecte et il a selectionner un prenom a ajouter.
	//appel a ma fonction.
	ajoutFav($_GET['idprenom']);
	echo "<meta http-equiv='refresh' content='1;URL=".$_GET['page']."'>";

}
elseif(!isset($_SESSION['Client'])){
	echo "<meta http-equiv='refresh' content='1;URL=".$_GET['page']."'>";
	echo "<h1> Vous devez disposer d'un compte pour selctionner des prenoms favoris </h1>";

}
else{
	echo "<meta http-equiv='refresh' content='1;URL=".$_GET['page']."'>";
	echo "<h1> Vous devez selectionner un prenom a ajouter a vos favoris</h1>";

}

?>


</head>


<body>

<?php



function ajoutFav($idprenom){
	
	include('bd.php'); //importation de ma feuille PHP bd.php
	$bdd = getBD(); //entrée dans la BD
	$q="SELECT selectionner.idPrenom FROM selectionner, client WHERE client.idClient=selectionner.idClient AND client.idClient=".$_SESSION['Client'][0]." AND selectionner.idPrenom=".$idprenom;
	
	$rep= $bdd->query($q); 
	
	$ligne = $rep->fetch();
	
	echo '<div class="contenuPage">';
	
	if($ligne['idPrenom']!=""){//si la personne a deja ce prenom en favoris
	//premier cas le prénom saisi existe deja dans les favoris de l'utilisateur.
		echo "<h1>le prenom selectionné existe déjà dans vos favoris</h1>";
		echo "<meta http-equiv='refresh' content='4;URL=accueil.php'>"; // changer le retour
	}
	else{
		$sql = 'INSERT INTO selectionner VALUES ('.$_SESSION['Client'][0].','.$idprenom.')';
		$bdd->exec($sql);
		echo "<h1>le prenom selectionné a été ajouté à vos favoris</h1>";
	}
	
	echo '</div>';
}


?>


<!-- retour accueil au cas ou -->
<a href="accueil.php">accueil </a>



</body>
</html>