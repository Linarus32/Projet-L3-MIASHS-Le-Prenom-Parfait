<!DOCTYPE html>
<html>

<head>
<title>Le prenom parfait </title>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
<link rel="stylesheet" href="../css/v1-mehdi.css" type="text/css" media="screen" />
</head>


<body>
<h2> Le Prenom Parfait</h2>

<?php 



$genre = $_GET['genre'];
$id = $_GET['id'];
$n = $_GET['n'];
$p = $_GET['p'];
$mail = $_GET['mail'];
$mdp1 = $_GET['mdp1'];





// "test ".(!isset($genre))."<br>";

	/*if($_GET['id']==""||
	//$_GET['pm']==""||
	isset()
	$_GET['n']==""||
	$_GET['p']==""||
	$_GET['mail']==""||
	$_GET['mdp1']==""||
	$_GET['mdp2']==""||
	$_GET['mdp1']!=$_GET['mdp2'])*/
if(isset($genre) and isset($id)  and isset($n)  and isset($p)  and isset($mail)  and isset($mdp1))	 {
		echo "<meta http-equiv='refresh' content='2;URL=../accueil.php'>";
		enregistrer ($id, $n, $p, $mdp1, $genre, $mail);
	}
	
	else{
		echo "<meta http-equiv= 'refresh' content='2;URL=inscription.php'>";
		echo "Tous les champs doivent être remplis";
		
	}


function enregistrer ($id, $n, $p, $mdp, $genre, $mail){
	include('../bd.php');
	$bdd= getBD();
	$sql = 'INSERT INTO client VALUES ("'.$id.'","'.$n.'","'.$p.'","'.$mdp.'","'.$genre.'","'.$mail.'")';
	//echo $sql;
	$bdd->exec($sql);
}	
	
	 





?>
	
</body>
</html>
