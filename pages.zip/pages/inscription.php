<!DOCTYPE html>
<html>

<head>
<title>Le prenom parfait </title>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
<link rel="stylesheet" href="../css/v1-mehdi.css" type="text/css" media="screen" />
</head>


<body>

<!-- bandeau avec logo et titre -->

<div id="bandeau">
	<a id="logo" href="../accueil.php"><img id="imagebandeau" src="../images/logo.tmp.png" height="150px" alt="logo" /></a>
	<ul class="menu">
		<li>
			<a href="../accueil.php">Acceuil </a>
		</li>
		<li> 
			<a href="bibliotheque.html">Bibliothèque</a>
		</li>
		<li>
			<a href="inscription.php">inscription/connexion</a>
		</li>
	</ul>
	<a id="logo2" href="v1.html"><img id="imagebandeau" src="../images/logo.tmp.png" height="150px" alt="logo" /></a>
</div>


<!-- Contenu de la page d'acceuil -->

<p id="separation1">


</p>

<!-- text 1 -->
<h2> Bienvenue </h2>
<div id="tout">

	

	<div id="membre">
		<p>Connexion</p>
		<form method="GET" action="connecter.php" autocomplete="off">
		<p><input class="bouton" type="text" placeholder="email(ex: xyz@email.fr)" name="mail" value=""></input></br></p>
		<p><input class="bouton" type="password" placeholder="Mot de passe..." name="mdp" value=""></br></p>
		<p><input class="bouton" type="submit" value="Connexion"></p>
		</form>
	</div>


	<div id="nouveau">
			<p>Inscription</p>
			<form method="GET" action="enregistrement2.php" autocomplete="off">	
			<p><input type="radio" name="genre" value="papa">Papa<input type="radio" name="genre" value="maman">Maman</p>
			<p><input class="bouton" type="text" placeholder="Login.." name="id" value=""></br></p>
			<p><input class="bouton" type="text" placeholder="Nom.." name="n" value=""></br></p>
			<p><input class="bouton" type="text" placeholder="Prenom.." name="p" value=""></br></p>
			<p><input class="bouton" type="text" placeholder="email(ex: xyz@email.fr)" name="mail" value=""></br></p>
			<p><input class="bouton" type="password" placeholder="Mot de passe..." name="mdp1" value=""></br></p>
			<p><input class="bouton" type="password" placeholder="Confirmer le mot de passe..." name="mdp2" ></br></p>
			<p><input class="bouton" type="submit" value="Inscription"></p>
			</form>	
		
	</div>
	</form>		

</div>

<p id="retour" > <a href="../accueil.php"> Retour a la page d'acceuil </a> </p>
</body>
</html>