<!DOCTYPE html>
<html>

<head>
	<title>Le prenom parfait </title>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
	<link rel="stylesheet" href="../css/v1-mehdi.css" type="text/css" media="screen" />
	<?php 

		if($_GET['mail']==""||
		$_GET['mdp']=="")
		{	
			echo "<meta http-equiv= 'refresh' content='2;URL=inscription.php'>";
			echo "Tous les champs doivent être remplis";
			}
		else{
			connexion ($_GET['mail'],$_GET['mdp']);
		
		
		}
?>
</head>
<body>
<?php 

function connexion ($mail, $mdp){
	include('../bd.php');
	$bdd= getBD();
	$sql= 'SELECT * FROM client WHERE (mail="'.$mail.'" AND mdp="'.$mdp.'")';
	$rep= $bdd->query($sql);

	$retour= $rep-> fetch();
	if($retour['mail']=="") {
		echo "<meta http-equiv= 'refresh' content='2;URL=inscription.php'>";
		echo "Veuillez créer un compte";
		}
	else{
		session_start();
		$_SESSION['Client'] = array($retour['id'],$retour['n'],$retour['p'],$retour['genre'],$retour['mail']);		
		echo "<meta http-equiv='refresh' content='1;URL=../accueil.php'>";
	}
	
}
?>
